### Fichier de base pour commencer un mini-projet 

Avec : 
* des photos randoms
* une navbar toute faite
* un body tout fait
* des sons
* des svg
* jQuery et Bootstrap reliés

#### Démarrer projet avec Sass 
* `npm run sass`

browser-sync start --proxy localhost/***  --files '**/*' --no-notify